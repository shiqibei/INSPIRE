"""Small generated examples for cohort rules and screening ties."""

import unittest

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score

from inspire_reproduction.evaluation import RankedScores
from inspire_reproduction.features import icu24_summary, index_and_outcome


class TestStudyRules(unittest.TestCase):
    def test_index_chronology_and_index_stay_death(self):
        operations = pd.DataFrame({
            'subject_id': [1, 1, 1, 2, 3, 4, 5],
            'op_id': [10, 20, 21, 30, 40, 50, 60],
            'opdate': [0] * 7,
            'anstart_time': [200, 100, 90, 0, 0, np.nan, 0],
            'asa': [2, 2, 6, 3, 3, 3, 3],
            'inhosp_death_time': [220, 43300, 105, 43800, 120, 200, 80],
            'discharge_time': [400, 43300, 235, 50000, 50, 300, np.nan],
        })
        index, event = index_and_outcome(operations)
        self.assertEqual(index.op_id.tolist(), [20, 30, 40, 60])
        np.testing.assert_array_equal(event, [1, 0, 0, 0])

    def test_icu_exclusions_preserve_absent_timestamp_as_non_event(self):
        index = pd.DataFrame({'opend_time': [50, 50, 50, np.nan, 50, 50],
                              'icuin_time': [50, 40, np.nan, 100, 1500, 200],
                              'discharge_time': [300, 300, 300, 300, 1900, 100]})
        self.assertEqual(icu24_summary(index), {'temporally_evaluable': 3, 'recorded_events': 1, 'rate': 1 / 3})

    def test_weighted_ties_and_capture(self):
        y = np.array([1, 0, 1, 0, 1])
        p = np.array([.9, .9, .5, .4, .4])
        weights = np.array([2, 1, 1, 0, 3], dtype=float)
        auc, ap, capture = RankedScores(y, p).evaluate(weights, np.array([1, 3, 4]))
        self.assertAlmostEqual(auc, roc_auc_score(y, p, sample_weight=weights))
        self.assertAlmostEqual(ap, average_precision_score(y, p, sample_weight=weights))
        np.testing.assert_allclose(capture, [2 / 3, 2, 3])


if __name__ == '__main__':
    unittest.main()
