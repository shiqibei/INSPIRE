"""Run the INSPIRE study locally and write aggregate results only."""

import argparse
import json
from pathlib import Path

import numpy as np
from threadpoolctl import threadpool_limits

from inspire_reproduction.evaluation import intervals, point_results
from inspire_reproduction.features import prepare
from inspire_reproduction.model import SEEDS, run_seed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-dir', required=True, type=Path, help='Directory containing credentialed INSPIRE v1.4.2 tables.')
    parser.add_argument('--out-dir', required=True, type=Path, help='Local directory to receive the aggregate results.')
    parser.add_argument('--five-seeds', action='store_true', help='Also refit under the four additional seeds.')
    parser.add_argument('--extensions', nargs='+', choices=['asa', 'procedure', 'icu24'], default=[], help='Run optional analyses.')
    parser.add_argument('--bootstrap', type=int, default=2000, help='Number of paired draws for the principal seed.')
    args = parser.parse_args()
    if args.bootstrap < 2:
        parser.error('--bootstrap must be at least 2.')
    destination = args.out_dir / 'aggregate_results.json'
    if destination.exists():
        parser.error('Output already exists. Choose another --out-dir.')
    if args.out_dir.resolve() == args.data_dir.resolve():
        parser.error('Use a separate directory for results.')
    x, y, specs, icu24 = prepare(args.data_dir, args.extensions)
    if len(y) < 10 or min(y.sum(), len(y) - y.sum()) < 5:
        parser.error('Five-fold stratification requires at least 5 cases of each outcome.')
    report = {'n': len(y), 'events': int(y.sum()), 'bootstrap_draws': args.bootstrap,
              'pointwise_intervals_condition_on_outer_fold_predictions': True,
              'data_release_expected': 'INSPIRE v1.4.2', 'extensions': args.extensions, 'runs': []}
    if icu24 is not None:
        report['descriptive_icu24'] = icu24
    names = tuple(specs)
    with threadpool_limits(limits=1):
        for seed in (SEEDS if args.five_seeds else SEEDS[:1]):
            p, folds, alerts, cs = run_seed(x, y, specs, seed)
            points = point_results(y, p, folds, alerts, names)
            report['runs'].append({'seed': seed, 'models': points, 'selected_c': cs})
            if seed == SEEDS[0]:
                report['principal_paired_contrasts'] = intervals(y, p, names, points, args.bootstrap)
    args.out_dir.mkdir(parents=True, exist_ok=True)
    with destination.open('x', encoding='utf-8') as out:
        json.dump(report, out, indent=2, ensure_ascii=False, allow_nan=False)
        out.write('\n')
    print(f'Aggregate results written to {destination}')


if __name__ == '__main__':
    main()
