"""区分度、校准、固定筛查工作量和患者级配对区间。"""

import numpy as np
import statsmodels.api as sm
from sklearn.metrics import average_precision_score, roc_auc_score

from .model import log_odds


PRIMARY = ('ASA_ref', 'M1', 'M2', 'LabOnly', 'M3')
FRACTIONS = np.array([.005, .01, .02, .05])
METRIC_NAMES = ('auroc', 'ap', 'brier')
BOOT_SEED = 2026101701


class RankedScores:
    """缓存相同分数的组，处理结局无关的边界并列。"""

    def __init__(self, y, p):
        self.y = y
        _, self.group = np.unique(-p, return_inverse=True)
        self.groups = int(self.group.max()) + 1

    def grouped(self, weights):
        sizes = np.bincount(self.group, weights=weights, minlength=self.groups)
        events = np.bincount(self.group, weights=weights * self.y, minlength=self.groups)
        return sizes, events

    def evaluate(self, weights, quotas):
        sizes, events = self.grouped(weights)
        count = np.cumsum(sizes)
        deaths = np.cumsum(events)
        positive = deaths[-1]
        negatives = sizes - events
        negative = negatives.sum()
        auroc = np.dot(events, negative - np.cumsum(negatives) + .5 * negatives) / (positive * negative)
        precision = np.divide(deaths, count, out=np.zeros_like(deaths), where=count > 0)
        ap = np.dot(events, precision) / positive
        cutoff = np.searchsorted(count, quotas)
        count_before = count[cutoff] - sizes[cutoff]
        deaths_before = deaths[cutoff] - events[cutoff]
        captured = deaths_before + (quotas - count_before) * events[cutoff] / sizes[cutoff]
        return auroc, ap, captured


def pair_list(names):
    requested = [('M1', 'ASA_ref'), ('M2', 'M1'), ('M3', 'M2'), ('M3', 'LabOnly'), ('M3', 'M1'), ('M3', 'ASA_ref'),
                 ('M1_no_ASA', 'M1'), ('M2_no_ASA', 'M2'), ('M3_no_ASA', 'M3'),
                 ('PCSOnly', 'LabOnly'), ('PCSOnly', 'M3'), ('LabOnly_PCS', 'LabOnly'), ('M3_PCS', 'M3'),
                 ('M3_PCS', 'LabOnly_PCS'), ('LabOnly_PCS_DX', 'LabOnly_PCS'), ('M3_PCS', 'M3_PCS_no_DX')]
    return [(names.index(a), names.index(b)) for a, b in requested if a in names and b in names]


def point_results(y, predictions, folds, alerts, names):
    n = len(y)
    quotas = np.ceil(n * FRACTIONS).astype(int)
    groups = [folds == k for k in range(1, 6)]
    shares = np.array([mask.sum() for mask in groups]) * quotas[1] / n
    allocated = shares.astype(int)
    priority = np.argsort(-(shares - allocated), kind='stable')
    allocated[priority[:quotas[1] - allocated.sum()]] += 1
    rows = {}
    for j, name in enumerate(names):
        p = predictions[:, j]
        _, _, capture = RankedScores(y, p).evaluate(np.ones(n), quotas)
        logits = log_odds(p)
        joint = sm.GLM(y, sm.add_constant(logits), family=sm.families.Binomial()).fit()
        level = sm.GLM(y, np.ones((n, 1)), offset=logits, family=sm.families.Binomial()).fit()
        fold_capture = sum(RankedScores(y[mask], p[mask]).evaluate(np.ones(mask.sum()), size)[2]
                           for mask, size in zip(groups, allocated) if size > 0)
        rows[name] = {'auroc': float(roc_auc_score(y, p)), 'ap': float(average_precision_score(y, p)),
                      'brier': float(np.mean((y - p)**2)), 'mean_prediction': float(p.mean()),
                      'observed_expected_ratio': float(y.sum() / p.sum()),
                      'citl': float(level.params[0]), 'slope': float(joint.params[1]),
                      'capture': dict(zip(map(str, quotas), capture.tolist())),
                      'capture_1pct_within_fold_quota': float(fold_capture),
                      'training_threshold_marked': float(alerts[:, j].sum()),
                      'training_threshold_captured': float(y @ alerts[:, j])}
    return rows


def intervals(y, p, names, points, repetitions):
    n = len(y)
    quotas = np.ceil(n * FRACTIONS).astype(int)
    rng = np.random.default_rng(BOOT_SEED)
    rng.integers(0, n, n)  # 与原始患者配对重抽样使用相同随机数流。
    rankings = [RankedScores(y, prob) for prob in p.T]
    errors = (p - y[:, None])**2
    draws = np.empty((repetitions, len(names), 3 + len(quotas)))
    for b in range(repetitions):
        weights = np.bincount(rng.integers(0, n, n), minlength=n).astype(float)
        while not (0 < weights @ y < n):
            weights = np.bincount(rng.integers(0, n, n), minlength=n).astype(float)
        for j, rank in enumerate(rankings):
            auc, ap, capture = rank.evaluate(weights, quotas)
            draws[b, j, :2] = auc, ap
            draws[b, j, 3:] = capture
        draws[b, :, 2] = weights @ errors / n
    estimates = np.array([[points[name][v] for v in METRIC_NAMES] +
                          [points[name]['capture'][str(k)] for k in quotas] for name in names])
    full = names.index('M3')
    primary_capture = [(full, names.index(b)) for b in PRIMARY[:-1]]
    local = np.stack([draws[:, a, 3:] - draws[:, b, 3:] for a, b in primary_capture], axis=1)
    center = np.stack([estimates[a, 3:] - estimates[b, 3:] for a, b in primary_capture])
    scales = local.std(axis=0, ddof=1)
    centered = np.divide(local - center, scales, out=np.zeros_like(local), where=scales > 0)
    critical = float(np.quantile(np.abs(centered).max(axis=(1, 2)), .95))
    out = {}
    labels = [*METRIC_NAMES, *(f'capture_{k}' for k in quotas)]
    for a, b in pair_list(names):
        delta = draws[:, a] - draws[:, b]
        est = estimates[a] - estimates[b]
        ci = np.quantile(delta, [.025, .975], axis=0).T
        rows = {label: {'estimate': float(est[j]), 'pointwise_ci95': ci[j].tolist()}
                for j, label in enumerate(labels)}
        if (a, b) == (full, names.index('M2')):
            for j, key in enumerate(METRIC_NAMES):
                rows[key]['bonferroni_three_metric'] = np.quantile(delta[:, j], [.05 / 6, 1 - .05 / 6]).tolist()
        if (a, b) in primary_capture:
            loc = primary_capture.index((a, b))
            for j, k in enumerate(quotas):
                half_width = critical * scales[loc, j]
                rows[f'capture_{k}']['simultaneous_local16_ci95'] = [float(center[loc, j] - half_width),
                                                                    float(center[loc, j] + half_width)]
        out[name_pair(names[a], names[b])] = rows
    return out


def name_pair(a, b):
    return f'{a} minus {b}'
