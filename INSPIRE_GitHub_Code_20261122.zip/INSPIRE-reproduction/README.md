# INSPIRE mortality screening reproduction

This repository contains the analysis code for the INSPIRE v1.4.2 study on preoperative clinical and laboratory information and 30-day in-hospital mortality at a fixed screening workload. It supports reproducible, exploratory internal evaluation.

## Obtain the data separately

Request the [INSPIRE v1.4.2 release through PhysioNet](https://doi.org/10.13026/1eay-yc85). Follow its credentialing, training, and [data-use terms](https://physionet.org/content/inspire/view-license/1.4.2/). Store the downloaded tables outside this repository. The script accepts `operations`, `diagnosis`, and `labs` in `.csv.gz` or `.csv` format. The optional procedure analysis reads `icd10_pcs` from `operations`.

Only source code, predictor definitions, dependencies, and tests are distributed here. The diagnostic mapping defines code groups for the analysis and contains no patient records. The workflow keeps individual predictions in memory and writes aggregate results only. Keep the result directory outside the Git working tree. Do not upload data files, patient-level results, or fitted models to this repository.

## Run locally

The reference environment used Python 3.12. Install the pinned dependencies in a clean virtual environment.

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests
python run_analysis.py --data-dir /path/to/inspire-1.4.2 --out-dir /path/to/local-results
```

On Windows, pass a quoted folder path wherever it contains spaces. To refit all five seed specifications and include ASA ablation, procedure and diagnosis sensitivity analyses, and the descriptive ICU analysis, select a fresh output directory.

```bash
python run_analysis.py --data-dir /path/to/inspire-1.4.2 --out-dir /path/to/local-results-extended --five-seeds --extensions asa procedure icu24
```

## What the code reproduces

| Analysis | Implementation |
| --- | --- |
| Cohort and endpoint | Earliest eligible anesthesia start per patient. The endpoint is recorded death within 30 days after anesthesia start and no later than index discharge. |
| Features | The diagnosis window ends eight hours before actual anesthesia start. The laboratory window begins 30 days before that cutoff. Diagnosis indicators represent eligible codes. |
| Principal evaluation | ASA reference, M1, M2, laboratory-only L, and M3. The pipeline uses 5 outer and 3 inner stratified folds, AP-based regularization selection, and inner out-of-fold logistic recalibration. |
| Screening | Pooled quotas of approximately 0.5%, 1%, 2%, and 5%, plus within-fold quotas and training-derived threshold point estimates. Ties use fractional allocation without consulting outcomes. |
| Uncertainty | Paired patient bootstrap of fixed principal-seed predictions. The principal M3–M2 metric family and the 16 principal capture contrasts receive the manuscript's local adjustments. Optional extension intervals are pointwise using the shared bootstrap stream. The ASA extension's pointwise intervals may differ slightly from those generated with the original ASA-specific stream. |
| Optional extensions | ASA removal, the recorded ICD-10-PCS factor, and its matched comparisons with and without the existing 18 diagnosis groups. |
| ICU description | Recorded ICU admission within 24 hours of surgery end, with its own time-eligible denominator. |

The release focuses on the principal mortality analysis and the optional analyses listed above. Manuscript figures and the full set of historical supplementary analyses are outside this release, including the secondary training-set resampling exercise and broad candidate-factor expansions. The inputs describe a retrospectively reconstructed time cutoff. The availability of recorded clinical fields and actual procedure codes at the intended screening time could not be established by the source data.

## Dataset citation

- Lim L, Lee H. *INSPIRE, a publicly available research dataset for perioperative medicine*, version 1.4.2. PhysioNet. 2026. [Dataset DOI](https://doi.org/10.13026/1eay-yc85)
- Lim L, Lee H, Jung CW, et al. *INSPIRE, a publicly available research dataset for perioperative medicine*. Scientific Data. 2024. [Original publication](https://doi.org/10.1038/s41597-024-03517-4)
- Pollard T, Moody BE, Lehman L, et al. *PhysioNet as a global platform for biomedical research*. Nature Health. 2026. [Platform citation](https://doi.org/10.1038/s44360-026-00096-z)
