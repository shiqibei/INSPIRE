"""从本地 INSPIRE v1.4.2 生成索引队列、结局和研究因子。"""

import json
from pathlib import Path

import pandas as pd


LABS = (
    'creatinine', 'hb', 'hct', 'wbc', 'sodium', 'calcium', 'potassium',
    'chloride', 'platelet', 'albumin', 'bun', 'phosphorus', 'ptinr', 'ast',
    'total_protein', 'alt', 'alp', 'aptt',
)
CLINICAL = ['age', 'sex', 'asa_ord', 'asa_missing', 'emop', 'department']
PCS = 'pcs_prefix'
MAP_FILE = Path(__file__).with_name('diagnosis_groups.json')


def source(folder, name):
    for suffix in ('.csv.gz', '.csv'):
        candidate = folder / f'{name}{suffix}'
        if candidate.is_file():
            return candidate
    raise FileNotFoundError(f'Required INSPIRE table missing: {name}.csv.gz or {name}.csv')


def index_and_outcome(operations):
    """先筛手术，再按时间选择每名患者的索引手术。"""
    index = (operations.loc[operations.asa.ne(6) & operations.anstart_time.notna()]
             .sort_values(['subject_id', 'anstart_time', 'opdate', 'op_id'])
             .drop_duplicates('subject_id').reset_index(drop=True))
    lag = index.inhosp_death_time - index.anstart_time
    outcome = (lag.between(0, 43200) & index.discharge_time.notna()
               & index.inhosp_death_time.le(index.discharge_time)).astype(int).to_numpy()
    return index, outcome


def load_latest_labs(folder, cutoff, ids):
    records = []
    for chunk in pd.read_csv(source(folder, 'labs'),
                             usecols=['subject_id', 'chart_time', 'item_name', 'value'],
                             chunksize=750000, low_memory=False):
        chunk = chunk.loc[chunk.item_name.isin(LABS)].copy()
        chunk['lead'] = chunk.subject_id.map(cutoff) - chunk.chart_time
        records.append(chunk.loc[chunk.lead.between(0, 43200),
                                 ['subject_id', 'chart_time', 'item_name', 'value', 'lead']])
    records = pd.concat(records, ignore_index=True)
    # 保留研究使用的同一患者、项目、时点并列规则及原表行顺序。
    latest = records.sort_values(['subject_id', 'item_name', 'lead']).drop_duplicates(['subject_id', 'item_name'])
    latest = latest.assign(value_num=pd.to_numeric(latest.value, errors='coerce'))
    return latest.pivot(index='subject_id', columns='item_name', values='value_num').reindex(index=ids, columns=LABS)


def icu24_summary(index):
    end, icu, discharge = index.opend_time, index.icuin_time, index.discharge_time
    unclear = end.isna() | discharge.isna() | icu.lt(end) | icu.gt(discharge)
    event = (icu - end).between(0, 1440) & icu.le(discharge) & ~unclear
    evaluable = int((~unclear).sum())
    count = int(event.sum())
    return {'temporally_evaluable': evaluable, 'recorded_events': count,
            'rate': count / evaluable if evaluable else None}


def prepare(folder, sections):
    cols = ['subject_id', 'op_id', 'opdate', 'anstart_time', 'asa', 'age', 'sex', 'emop',
            'department', 'inhosp_death_time', 'discharge_time']
    if 'procedure' in sections:
        cols.append('icd10_pcs')
    if 'icu24' in sections:
        cols.extend(['opend_time', 'icuin_time'])
    ops = pd.read_csv(source(folder, 'operations'), usecols=cols, dtype={'icd10_pcs': 'string'}, low_memory=False)
    index, y = index_and_outcome(ops)
    ids = index.subject_id.to_numpy()
    cutoff = (index.anstart_time - 480).set_axis(ids)
    if index.sex.isna().any():
        raise ValueError('Unexpected missing sex in the analysis cohort. Check the release and source files.')
    x = pd.DataFrame({'age': index.age.astype(float), 'sex': index.sex.str.upper().eq('M').astype(float),
                      'asa_ord': index.asa.astype(float), 'asa_missing': index.asa.isna().astype(float),
                      'emop': index.emop.astype(float), 'department': index.department.fillna('UNRECORDED').astype(str)})
    mapping = json.loads(MAP_FILE.read_text(encoding='utf-8'))
    diagnoses = pd.read_csv(source(folder, 'diagnosis'), usecols=['subject_id', 'chart_time', 'icd10_cm'], low_memory=False)
    diagnoses = diagnoses.loc[diagnoses.chart_time.le(diagnoses.subject_id.map(cutoff))].copy()
    prefixes = diagnoses.icd10_cm.astype(str).str[:3]
    for factor, codes in mapping.items():
        x[factor] = index.subject_id.isin(diagnoses.loc[prefixes.isin(codes), 'subject_id']).astype(float)
    lab_values = load_latest_labs(folder, cutoff, ids)
    for item in LABS:
        x[f'lab_{item}'] = lab_values[item].to_numpy(dtype=float)
    labs = [f'lab_{item}' for item in LABS]
    dx = list(mapping)
    m2 = CLINICAL + dx
    m3 = m2 + labs
    specs = {'ASA_ref': ['asa_ord'], 'M1': CLINICAL, 'M2': m2, 'LabOnly': labs, 'M3': m3}
    if 'asa' in sections:
        for model in ('M1', 'M2', 'M3'):
            specs[model + '_no_ASA'] = [c for c in specs[model] if c not in ('asa_ord', 'asa_missing')]
    if 'procedure' in sections:
        codes = index.icd10_pcs.str.strip().str.upper()
        valid = codes.str.fullmatch(r'[0-9A-HJ-NP-Z]{5}', na=False)
        x[PCS] = codes.str[:3].where(valid, 'UNKNOWN').astype(str)
        specs.update({'PCSOnly': [PCS], 'LabOnly_PCS': labs + [PCS], 'M3_PCS': m3 + [PCS],
                      'LabOnly_PCS_DX': labs + [PCS] + dx, 'M3_PCS_no_DX': CLINICAL + labs + [PCS]})
    icu24 = icu24_summary(index) if 'icu24' in sections else None
    return x, y, specs, icu24
