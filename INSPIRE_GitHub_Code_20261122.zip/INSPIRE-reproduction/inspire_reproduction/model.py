"""固定折分、折内预处理、调参及逻辑再校准。"""

import warnings

import numpy as np
import statsmodels.api as sm
from scipy.special import expit
from sklearn.compose import ColumnTransformer
from sklearn.exceptions import ConvergenceWarning
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score
from sklearn.model_selection import StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from .features import PCS


GRID = (0.01, 0.03, 0.1, 0.3, 1.0)
SEEDS = tuple(range(20261001, 20261006))


def log_odds(p):
    p = np.clip(p, 1e-8, 1 - 1e-8)
    return np.log(p / (1 - p))


def preprocessor(columns):
    numeric = [v for v in columns if v in ('age', 'asa_ord') or v.startswith('lab_')]
    binary = [v for v in columns if v not in numeric and v not in ('department', PCS)]
    steps = []
    if numeric:
        transform = Pipeline([('median', SimpleImputer(strategy='median', keep_empty_features=True)),
                              ('scale', StandardScaler())])
        steps.append(('numeric', transform, numeric))
    if binary:
        steps.append(('binary', SimpleImputer(strategy='most_frequent', keep_empty_features=True), binary))
    if 'department' in columns:
        steps.append(('department', OneHotEncoder(drop='first', handle_unknown='ignore', sparse_output=False), ['department']))
    if PCS in columns:
        encoder = OneHotEncoder(min_frequency=100, handle_unknown='infrequent_if_exist', sparse_output=False)
        steps.append(('procedure', encoder, [PCS]))
    return ColumnTransformer(steps, sparse_threshold=0)


def develop(x, y, train, test, seed):
    splitter = StratifiedKFold(3, shuffle=True, random_state=seed)
    inner_probs = np.full((len(train), len(GRID)), np.nan)
    scores = np.empty((3, len(GRID)))
    for fold, (tr, val) in enumerate(splitter.split(train, y[train])):
        pre = preprocessor(x.columns)
        train_x = pre.fit_transform(x.iloc[train[tr]], y[train[tr]])
        valid_x = pre.transform(x.iloc[train[val]])
        for j, c in enumerate(GRID):
            model = LogisticRegression(C=c, max_iter=3000, class_weight=None).fit(train_x, y[train[tr]])
            prob = model.predict_proba(valid_x)[:, 1]
            inner_probs[val, j] = prob
            scores[fold, j] = average_precision_score(y[train[val]], prob)
    best = int(np.argmax(scores.mean(axis=0)))
    model = Pipeline([('prepare', preprocessor(x.columns)),
                      ('logistic', LogisticRegression(C=GRID[best], max_iter=3000, class_weight=None))])
    model.fit(x.iloc[train], y[train])
    logits = log_odds(inner_probs[:, best])
    cal = sm.GLM(y[train], sm.add_constant(logits), family=sm.families.Binomial()).fit()
    if not cal.converged or not np.isfinite(cal.params).all():
        raise RuntimeError('Inner out-of-fold calibration did not converge.')
    test_probs = expit(cal.params[0] + cal.params[1] * log_odds(model.predict_proba(x.iloc[test])[:, 1]))
    inner_calibrated = expit(cal.params[0] + cal.params[1] * logits)
    return test_probs, inner_calibrated, GRID[best]


def run_seed(x, y, specs, seed):
    splitter = StratifiedKFold(5, shuffle=True, random_state=seed)
    predictions = np.full((len(y), len(specs)), np.nan)
    folds = np.empty(len(y), dtype=int)
    alert_gates = np.zeros_like(predictions)
    selected_c = {name: [] for name in specs}
    with warnings.catch_warnings():
        warnings.simplefilter('error', ConvergenceWarning)
        warnings.filterwarnings('ignore', message='Found unknown categories', category=UserWarning)
        for k, (tr, te) in enumerate(splitter.split(x, y), 1):
            folds[te] = k
            for j, (name, cols) in enumerate(specs.items()):
                p, inner_p, c = develop(x[cols], y, tr, te, seed + 1000 * k)
                predictions[te, j] = p
                selected_c[name].append(c)
                quota = int(np.ceil(len(inner_p) * .01))
                cutoff = np.partition(inner_p, -quota)[-quota]
                higher = np.count_nonzero(inner_p > cutoff)
                rate = (quota - higher) / np.count_nonzero(inner_p == cutoff)
                alert_gates[te, j] = (p > cutoff) + rate * (p == cutoff)
            print(f'Seed {seed}: outer fold {k}/5 completed.', flush=True)
    if not np.isfinite(predictions).all():
        raise RuntimeError('Missing outer-fold predictions.')
    return predictions, folds, alert_gates, selected_c
