"""Code-only reproduction of the INSPIRE mortality screening analyses."""
